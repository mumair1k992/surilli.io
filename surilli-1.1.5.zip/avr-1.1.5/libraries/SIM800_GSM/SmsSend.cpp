/*
  SmsSend.cpp - Library for sending message to some GSM number (SoS).
  Created by Silverback pvt limited, August 21, 2017.
  Released into the public domain.
*/

#include "Arduino.h"
#include "SmsSend.h"
#include <SoftwareSerial.h>


using namespace std;


SmsSend::SmsSend(String num, String msg)
{
	//num = "abcd";
  	_num= num;
  	_msg= msg;
}

String SmsSend::exec()
{	

	SoftwareSerial mySerial(8, 9); // RX, TX
  	mySerial.begin(9600);
  	delay(10);
  // read the value from the sensor:
  delay (1000);
mySerial.println("AT+CMGF=1");  //send text mode for send and receive msg.
mySerial_read();
delay(1000);

mySerial.println("AT+CFUN=1");  //to enable some functions
mySerial_read();
delay(1000);

mySerial.println(" AT+CSCS= \"GSM\" ");
mySerial_read();
delay(1000);
Serial.println(_num);
Serial.println(_msg);
String s =  String ("AT+CMGS=")+  "\"" + _num + "\"" "\r";
String q =  String ( _msg ) + "\u001A";
mySerial.println(s);
mySerial_read();
delay(1000);
mySerial.print(q);
mySerial_read();
delay(1000);



mySerial.println("Message Sent");
return "Message Send";
}


void SmsSend::mySerial_read()

	{ 
		SoftwareSerial mySerial(8, 9); // RX, TX
  
  	mySerial.begin(9600);
  	delay(10);
	
		if (mySerial.available() > 0) 
		{
          
         String letter = mySerial.readString();
         
         Serial.println(letter);
         
        }
        delay(1000);
	}


